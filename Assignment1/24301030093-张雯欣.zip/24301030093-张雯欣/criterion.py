"""
criterion
"""
import math

def get_criterion_function(criterion):
    if criterion == "info_gain":
        return __info_gain
    elif criterion == "info_gain_ratio":
        return __info_gain_ratio
    elif criterion == "gini":
        return __gini_index
    elif criterion == "error_rate":
        return __error_rate


def __label_stat(y, l_y, r_y):
    """Count the number of labels of nodes"""
    left_labels = {}
    right_labels = {}
    all_labels = {}
    for t in y.reshape(-1):
        if t not in all_labels:
            all_labels[t] = 0
        all_labels[t] += 1
    for t in l_y.reshape(-1):
        if t not in left_labels:
            left_labels[t] = 0
        left_labels[t] += 1
    for t in r_y.reshape(-1):
        if t not in right_labels:
            right_labels[t] = 0
        right_labels[t] += 1

    return all_labels, left_labels, right_labels


def __info_gain(y, l_y, r_y):
    """
    Calculate the info gain

    y, l_y, r_y: label array of father node, left child node, right child node
    """
    all_labels, left_labels, right_labels = __label_stat(y, l_y, r_y)
    n = sum(all_labels.values())
    if n == 0:
        return 0.0

    def entropy(counts):
        total = sum(counts.values())
        if total == 0:
            return 0.0
        return -math.fsum((c / total) * math.log2(c / total)
                          for c in counts.values())

    left_weight = sum(left_labels.values()) / n
    right_weight = sum(right_labels.values()) / n
    return (entropy(all_labels) - left_weight * entropy(left_labels)
            - right_weight * entropy(right_labels))


def __info_gain_ratio(y, l_y, r_y):
    """
    Calculate the info gain ratio

    y, l_y, r_y: label array of father node, left child node, right child node
    """
    info_gain = __info_gain(y, l_y, r_y)
    n = y.size
    if n == 0 or l_y.size == 0 or r_y.size == 0:
        return 0.0
    left_weight, right_weight = l_y.size / n, r_y.size / n
    split_info = -(left_weight * math.log2(left_weight)
                   + right_weight * math.log2(right_weight))
    return info_gain / split_info if split_info > 0.0 else 0.0


def __gini_index(y, l_y, r_y):
    """
    Calculate the gini index

    y, l_y, r_y: label array of father node, left child node, right child node
    """
    all_labels, left_labels, right_labels = __label_stat(y, l_y, r_y)
    n = sum(all_labels.values())
    if n == 0:
        return 0.0

    def gini(counts):
        total = sum(counts.values())
        if total == 0:
            return 0.0
        return 1.0 - math.fsum((c / total) ** 2 for c in counts.values())

    before = gini(all_labels)
    after = (sum(left_labels.values()) / n * gini(left_labels)
             + sum(right_labels.values()) / n * gini(right_labels))
    return before - after


def __error_rate(y, l_y, r_y):
    """Calculate the error rate"""
    all_labels, left_labels, right_labels = __label_stat(y, l_y, r_y)
    n = sum(all_labels.values())
    if n == 0:
        return 0.0

    # Weighted classification error equals misclassified count / n.
    # Subtract integer counts first so a zero improvement is exactly zero,
    # rather than a tiny positive roundoff that could trigger a false split.
    before = n - max(all_labels.values())
    after = (sum(left_labels.values()) - max(left_labels.values(), default=0)
             + sum(right_labels.values()) - max(right_labels.values(), default=0))
    return (before - after) / n
