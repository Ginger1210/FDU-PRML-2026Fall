import os
import numpy as np
from typing import List, Tuple
from data_generate import load_prepared_dataset
from viz_knn import plot_k_curve, plot_decision_boundary_multi

# 输出目录
OUT_DIR = "./output"
DATA_DIR = "./input_knn"

# ============ 1：pairwise_dist ============
def pairwise_dist(X_test, X_train, metric, mode):
    """
    Compute pairwise distances between X_test (Nte,D) and X_train (Ntr,D).

    Required:
      - L2 distance 'l2' with modes:
          * 'two_loops'  
          * 'no_loops' 
      - 'cosine' distance (distance = 1 - cosine_similarity)
        Zero vectors have similarity 0 to any vector, including zero.
    """
    X_test = np.asarray(X_test, dtype=np.float64)
    X_train = np.asarray(X_train, dtype=np.float64)
    if X_test.ndim != 2 or X_train.ndim != 2:
        raise ValueError("Inputs must be two-dimensional feature matrices.")
    Nte, D  = X_test.shape
    Ntr, D2 = X_train.shape
    if D != D2:
        raise ValueError("Dim mismatch between test and train.")

    if metric == "l2":
        if mode == "two_loops":
            distances = np.empty((Nte, Ntr), dtype=np.float64)
            for i in range(Nte):
                for j in range(Ntr):
                    diff = X_test[i] - X_train[j]
                    distances[i, j] = np.sqrt(np.sum(diff * diff))
            return distances

        elif mode == "no_loops":
            test_sq = np.sum(X_test ** 2, axis=1, keepdims=True)
            train_sq = np.sum(X_train ** 2, axis=1)[None, :]
            squared = test_sq + train_sq - 2.0 * (X_test @ X_train.T)
            # Roundoff may make a theoretically nonnegative entry negative.
            return np.sqrt(np.maximum(squared, 0.0))

        else:
            raise ValueError("Unknown mode for L2.")

    elif metric == "cosine":
        test_norm = np.linalg.norm(X_test, axis=1, keepdims=True)
        train_norm = np.linalg.norm(X_train, axis=1, keepdims=True)
        test_unit = np.divide(X_test, test_norm, out=np.zeros_like(X_test),
                              where=test_norm != 0)
        train_unit = np.divide(X_train, train_norm, out=np.zeros_like(X_train),
                               where=train_norm != 0)
        similarity = np.clip(test_unit @ train_unit.T, -1.0, 1.0)
        return 1.0 - similarity
    else:
        raise ValueError("metric must be 'l2' or 'cosine'.")


# ============ 2：knn_predict（多数表决） ============
def knn_predict(X_test, X_train, y_train, k, metric, mode):
    """
    kNN prediction.
    Majority vote with the requested distance; ties use the smallest label.

    Returns
    -------
    y_pred : (Nte,) int
    """
    dists = pairwise_dist(X_test, X_train, metric=metric, mode=mode)
    y_train = np.asarray(y_train).reshape(-1).astype(int)
    if len(y_train) != dists.shape[1]:
        raise ValueError("Training features and labels must have the same length.")
    if (isinstance(k, (bool, np.bool_))
            or not isinstance(k, (int, np.integer))
            or not 1 <= k <= len(y_train)):
        raise ValueError("k must be an integer between 1 and the training size.")
    Nte = dists.shape[0]
    y_pred = np.zeros(Nte, dtype=int)

    for i in range(Nte):
        # Stable sorting makes equal-distance neighbors deterministic.
        idx = np.argsort(dists[i], kind="stable")[:k]
        neighbors = y_train[idx]

        labels, counts = np.unique(neighbors, return_counts=True)
        # np.unique sorts labels; argmax selects the first maximum count.
        y_pred[i] = labels[np.argmax(counts)]

    return y_pred


# ============ 3：select_k_by_validation ============
def select_k_by_validation(X_train, y_train, X_val, y_val, ks: List[int], metric, mode) -> Tuple[int, List[float]]:
    """
    Grid-search K on validation set.

    Returns
    -------
    best_k : int
    accs   : list of validation accuracies aligned with ks
    """
    ks = list(ks)
    y_val = np.asarray(y_val).reshape(-1)
    if not ks:
        raise ValueError("ks must contain at least one candidate.")
    if y_val.size == 0 or len(X_val) != y_val.size:
        raise ValueError("Validation data must be nonempty and match its labels.")

    accs = []
    best_k, best_correct = None, -1
    for k in ks:
        pred = knn_predict(X_val, X_train, y_train, k, metric, mode)
        correct = int(np.count_nonzero(pred == y_val))
        accs.append(float(correct / y_val.size))
        # Integer correct counts avoid approximate floating-point tie tests.
        if correct > best_correct or (correct == best_correct and k < best_k):
            best_k, best_correct = int(k), correct
    return best_k, accs


def run_with_visualization(metric="l2", mode="no_loops"):
    X_train, y_train, X_val, y_val, X_test, y_test = load_prepared_dataset(DATA_DIR)

    ks = [1, 3, 5, 7, 9, 11, 13]

    best_k, accs = select_k_by_validation(X_train, y_train, X_val, y_val,
                                          ks, metric=metric, mode=mode)
    print(f"[ModelSelect] metric={metric} best k={best_k} (val acc={max(accs):.4f})")
    plot_k_curve(ks, accs, os.path.join(OUT_DIR, f"knn_k_curve_{metric}.png"))

    X_trv = np.vstack([X_train, X_val]); y_trv = np.hstack([y_train, y_val])
    def predict_fn_for_k(k):
        return lambda Xq: knn_predict(Xq, X_trv, y_trv, k, metric=metric, mode=mode)

    ks_panel = sorted(set(ks + [best_k]))
    plot_decision_boundary_multi(predict_fn_for_k, X_train, y_train, X_test, y_test,
                                 ks=ks_panel,
                                 out_path=os.path.join(OUT_DIR, f"knn_boundary_grid_{metric}.png"),
                                 grid_n=200, batch_size=4096)


if __name__ == "__main__":
    # metric: ["l2", "cosine"];  mode: ["two_loops", "no_loops"]
    for metric in ["l2", "cosine"]:
        run_with_visualization(metric=metric, mode="no_loops")
